1- edit the java file to change the URL of the VSD
2- Build: mvn clean install -DskipTests
3- Run: java -jar target/vspk-examples-1.0-jar-with-dependencies.jar
